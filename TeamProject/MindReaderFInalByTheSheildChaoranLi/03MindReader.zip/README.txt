Mars4_5#.jar should be use, otherwise errors may occur.
MindReader2_0 is the final version.

MindReader2_0s remove the shuffle for numbers in each cards:
Because the numbers after being shuffled are often misread, the final results are not consistent with the numbers in player's mind. This version is just to prove that the algorithm is correct.

GLHF
SCGTall